
# Discord Roblox Background Check Bot

This bot checks Roblox accounts for risk factors and returns a percentage risk score based on a list of rules. Automatically kicks users that exceed the risk threshold.

## Files
- `main.py`: Bot logic
- `requirements.txt`: Dependencies for Render or Replit
- Add a `TOKEN` environment variable for your bot's token

## Hosting
Recommended: Render.com with UptimeRobot for 24/7 uptime
